<?php class Model_Data_Dosen extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    function get($nipDosen)
    {
        $query = $this->db->get_where('dosen', array('id_dosen' => $nipDosen));
        return $query;
    }
    function ambilMataKuliah($id)
    {
        $this->db->select('*');
        $this->db->from('tugas_dosen a');
        $this->db->join('dosen b', 'a.id_dosen = b.id_dosen');
        $this->db->join('matkul c', 'a.id_matkul = c.id_matkul');
        $this->db->where('a.id_dosen', $id);
        $query = $this->db->get();
        return $query->result_array();
    }
}
